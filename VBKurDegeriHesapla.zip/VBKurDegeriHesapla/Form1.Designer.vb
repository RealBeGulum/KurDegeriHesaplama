﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MiktarTXT = New System.Windows.Forms.TextBox()
        Me.MiktarLBL = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TLTxt = New System.Windows.Forms.TextBox()
        Me.TLLBL = New System.Windows.Forms.Label()
        Me.DolarLBL = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DolarTXT = New System.Windows.Forms.TextBox()
        Me.EuroLBL = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.EuroTXT = New System.Windows.Forms.TextBox()
        Me.AltinLBL = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.AltinTXT = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.AltinRBTN = New System.Windows.Forms.RadioButton()
        Me.EuroRBTN = New System.Windows.Forms.RadioButton()
        Me.DolarRBTN = New System.Windows.Forms.RadioButton()
        Me.TLRBTN = New System.Windows.Forms.RadioButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MiktarTXT
        '
        Me.MiktarTXT.Location = New System.Drawing.Point(28, 29)
        Me.MiktarTXT.MaxLength = 8
        Me.MiktarTXT.Name = "MiktarTXT"
        Me.MiktarTXT.Size = New System.Drawing.Size(190, 20)
        Me.MiktarTXT.TabIndex = 0
        Me.MiktarTXT.Text = "1"
        Me.MiktarTXT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MiktarLBL
        '
        Me.MiktarLBL.AutoSize = True
        Me.MiktarLBL.Location = New System.Drawing.Point(78, 10)
        Me.MiktarLBL.Name = "MiktarLBL"
        Me.MiktarLBL.Size = New System.Drawing.Size(92, 13)
        Me.MiktarLBL.TabIndex = 1
        Me.MiktarLBL.Text = "Çevrilecek Miktar:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(45, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Türk Lirası:"
        '
        'TLTxt
        '
        Me.TLTxt.Location = New System.Drawing.Point(28, 25)
        Me.TLTxt.MaxLength = 8
        Me.TLTxt.Name = "TLTxt"
        Me.TLTxt.Size = New System.Drawing.Size(100, 20)
        Me.TLTxt.TabIndex = 2
        Me.TLTxt.Text = "1"
        '
        'TLLBL
        '
        Me.TLLBL.AutoSize = True
        Me.TLLBL.Location = New System.Drawing.Point(136, 28)
        Me.TLLBL.Name = "TLLBL"
        Me.TLLBL.Size = New System.Drawing.Size(13, 13)
        Me.TLLBL.TabIndex = 4
        Me.TLLBL.Text = "₺"
        '
        'DolarLBL
        '
        Me.DolarLBL.AutoSize = True
        Me.DolarLBL.Location = New System.Drawing.Point(136, 74)
        Me.DolarLBL.Name = "DolarLBL"
        Me.DolarLBL.Size = New System.Drawing.Size(13, 13)
        Me.DolarLBL.TabIndex = 7
        Me.DolarLBL.Text = "$"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(45, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Dolar Kuru:"
        '
        'DolarTXT
        '
        Me.DolarTXT.Location = New System.Drawing.Point(28, 71)
        Me.DolarTXT.MaxLength = 8
        Me.DolarTXT.Name = "DolarTXT"
        Me.DolarTXT.Size = New System.Drawing.Size(100, 20)
        Me.DolarTXT.TabIndex = 5
        Me.DolarTXT.Text = "6.0572"
        '
        'EuroLBL
        '
        Me.EuroLBL.AutoSize = True
        Me.EuroLBL.Location = New System.Drawing.Point(136, 120)
        Me.EuroLBL.Name = "EuroLBL"
        Me.EuroLBL.Size = New System.Drawing.Size(13, 13)
        Me.EuroLBL.TabIndex = 10
        Me.EuroLBL.Text = "£"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(45, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Euro Kuru:"
        '
        'EuroTXT
        '
        Me.EuroTXT.Location = New System.Drawing.Point(28, 117)
        Me.EuroTXT.MaxLength = 8
        Me.EuroTXT.Name = "EuroTXT"
        Me.EuroTXT.Size = New System.Drawing.Size(100, 20)
        Me.EuroTXT.TabIndex = 8
        Me.EuroTXT.Text = "6.7670"
        '
        'AltinLBL
        '
        Me.AltinLBL.AutoSize = True
        Me.AltinLBL.Location = New System.Drawing.Point(136, 170)
        Me.AltinLBL.Name = "AltinLBL"
        Me.AltinLBL.Size = New System.Drawing.Size(16, 13)
        Me.AltinLBL.TabIndex = 13
        Me.AltinLBL.Text = "gr"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(45, 151)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Altın Kuru:"
        '
        'AltinTXT
        '
        Me.AltinTXT.Location = New System.Drawing.Point(28, 167)
        Me.AltinTXT.MaxLength = 8
        Me.AltinTXT.Name = "AltinTXT"
        Me.AltinTXT.Size = New System.Drawing.Size(100, 20)
        Me.AltinTXT.TabIndex = 11
        Me.AltinTXT.Text = "248.54"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.AltinRBTN)
        Me.Panel1.Controls.Add(Me.EuroRBTN)
        Me.Panel1.Controls.Add(Me.DolarRBTN)
        Me.Panel1.Controls.Add(Me.TLRBTN)
        Me.Panel1.Controls.Add(Me.AltinLBL)
        Me.Panel1.Controls.Add(Me.AltinTXT)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.TLTxt)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.EuroLBL)
        Me.Panel1.Controls.Add(Me.TLLBL)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.DolarTXT)
        Me.Panel1.Controls.Add(Me.EuroTXT)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.DolarLBL)
        Me.Panel1.Location = New System.Drawing.Point(18, 83)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(249, 210)
        Me.Panel1.TabIndex = 14
        '
        'AltinRBTN
        '
        Me.AltinRBTN.AutoSize = True
        Me.AltinRBTN.Location = New System.Drawing.Point(8, 171)
        Me.AltinRBTN.Name = "AltinRBTN"
        Me.AltinRBTN.Size = New System.Drawing.Size(14, 13)
        Me.AltinRBTN.TabIndex = 16
        Me.AltinRBTN.TabStop = True
        Me.AltinRBTN.UseVisualStyleBackColor = True
        '
        'EuroRBTN
        '
        Me.EuroRBTN.AutoSize = True
        Me.EuroRBTN.Location = New System.Drawing.Point(8, 121)
        Me.EuroRBTN.Name = "EuroRBTN"
        Me.EuroRBTN.Size = New System.Drawing.Size(14, 13)
        Me.EuroRBTN.TabIndex = 15
        Me.EuroRBTN.TabStop = True
        Me.EuroRBTN.UseVisualStyleBackColor = True
        '
        'DolarRBTN
        '
        Me.DolarRBTN.AutoSize = True
        Me.DolarRBTN.Location = New System.Drawing.Point(8, 75)
        Me.DolarRBTN.Name = "DolarRBTN"
        Me.DolarRBTN.Size = New System.Drawing.Size(14, 13)
        Me.DolarRBTN.TabIndex = 14
        Me.DolarRBTN.TabStop = True
        Me.DolarRBTN.UseVisualStyleBackColor = True
        '
        'TLRBTN
        '
        Me.TLRBTN.AutoSize = True
        Me.TLRBTN.Location = New System.Drawing.Point(8, 28)
        Me.TLRBTN.Name = "TLRBTN"
        Me.TLRBTN.Size = New System.Drawing.Size(14, 13)
        Me.TLRBTN.TabIndex = 0
        Me.TLRBTN.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.MiktarLBL)
        Me.Panel2.Controls.Add(Me.MiktarTXT)
        Me.Panel2.Location = New System.Drawing.Point(18, 18)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(249, 59)
        Me.Panel2.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(287, 310)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(303, 349)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kur Hesaplama"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MiktarTXT As TextBox
    Friend WithEvents MiktarLBL As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TLTxt As TextBox
    Friend WithEvents TLLBL As Label
    Friend WithEvents DolarLBL As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents DolarTXT As TextBox
    Friend WithEvents EuroLBL As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents EuroTXT As TextBox
    Friend WithEvents AltinLBL As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents AltinTXT As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TLRBTN As RadioButton
    Friend WithEvents AltinRBTN As RadioButton
    Friend WithEvents EuroRBTN As RadioButton
    Friend WithEvents DolarRBTN As RadioButton
End Class
