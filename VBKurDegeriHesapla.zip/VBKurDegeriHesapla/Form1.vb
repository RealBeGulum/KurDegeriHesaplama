﻿Public Class Form1
    '_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
    '/////// Coded by eodev/#RealBeGulum \\\\\\\\\
    '_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
    Private i, j, k, n, m As Double
    'Kurları yenile.
    Private Sub RefreshRate()
        i = Convert.ToDouble(MiktarTXT.Text.Replace(".", ","))
        j = Convert.ToDouble(TLTxt.Text.Replace(".", ","))
        k = Convert.ToDouble(DolarTXT.Text.Replace(".", ","))
        n = Convert.ToDouble(EuroTXT.Text.Replace(".", ","))
        m = Convert.ToDouble(AltinTXT.Text.Replace(".", ","))
    End Sub
    'Türk lirası için çevir.
    Private Sub TLRBTN_CheckedChanged(sender As Object, e As EventArgs) Handles TLRBTN.CheckedChanged
        RefreshRate()
        TLLBL.Text = "₺ " & (i).ToString("N")
        DolarLBL.Text = "$ " & ((i * j) / k).ToString("N")
        EuroLBL.Text = "£ " & ((i * j) / n).ToString("N")
        AltinLBL.Text = "gr " & ((i * j) / m).ToString("N")
    End Sub
    'Dolar için çevir.
    Private Sub DolarRBTN_CheckedChanged(sender As Object, e As EventArgs) Handles DolarRBTN.CheckedChanged
        RefreshRate()
        DolarLBL.Text = "$ " & (i).ToString("N")
        TLLBL.Text = "₺ " & ((i * k) / j).ToString("N")
        EuroLBL.Text = "£ " & ((i * k) / n).ToString("N")
        AltinLBL.Text = "gr " & ((i * k) / m).ToString("N")
    End Sub
    'Euro için çevir.
    Private Sub EuroRBTN_CheckedChanged(sender As Object, e As EventArgs) Handles EuroRBTN.CheckedChanged
        RefreshRate()
        EuroLBL.Text = "£ " & (i).ToString("N")
        TLLBL.Text = "₺ " & ((i * n) / j).ToString("N")
        DolarLBL.Text = "$ " & ((i * n) / k).ToString("N")
        AltinLBL.Text = "gr " & ((i * n) / m).ToString("N")
    End Sub
    'Altın için çevir.
    Private Sub AltinRBTN_CheckedChanged(sender As Object, e As EventArgs) Handles AltinRBTN.CheckedChanged
        RefreshRate()
        AltinLBL.Text = "gr " & (i).ToString("N")
        TLLBL.Text = "₺ " & ((i * m) / j).ToString("N")
        DolarLBL.Text = "$ " & ((i * m) / k).ToString("N")
        EuroLBL.Text = "£ " & ((i * m) / n).ToString("N")
    End Sub
    '_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
    '/////// Coded by eodev/#RealBeGulum \\\\\\\\\
    '_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
End Class
