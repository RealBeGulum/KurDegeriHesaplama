﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CSharpKurDegeriHesapla
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // _-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
        // /////// Coded by eodev/#RealBeGulum \\\\\\\\\
        // _-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
        private double i, j, k, n, m;
        // Kurları yenile.
        private void RefreshRate()
        {
            i = Convert.ToDouble(MiktarTXT.Text.Replace(".", ","));
            j = Convert.ToDouble(TLTxt.Text.Replace(".", ","));
            k = Convert.ToDouble(DolarTXT.Text.Replace(".", ","));
            n = Convert.ToDouble(EuroTXT.Text.Replace(".", ","));
            m = Convert.ToDouble(AltinTXT.Text.Replace(".", ","));
        }
        // Türk lirası için çevir.
        private void TLRBTN_CheckedChanged(object sender, EventArgs e)
        {
            RefreshRate();
            TLLBL.Text = "₺ " + (i).ToString("N");
            DolarLBL.Text = "$ " + ((i * j) / k).ToString("N");
            EuroLBL.Text = "£ " + ((i * j) / n).ToString("N");
            AltinLBL.Text = "gr " + ((i * j) / m).ToString("N");
        }
        // Dolar için çevir.
        private void DolarRBTN_CheckedChanged(object sender, EventArgs e)
        {
            RefreshRate();
            DolarLBL.Text = "$ " + (i).ToString("N");
            TLLBL.Text = "₺ " + ((i * k) / j).ToString("N");
            EuroLBL.Text = "£ " + ((i * k) / n).ToString("N");
            AltinLBL.Text = "gr " + ((i * k) / m).ToString("N");
        }
        // Euro için çevir.
        private void EuroRBTN_CheckedChanged(object sender, EventArgs e)
        {
            RefreshRate();
            EuroLBL.Text = "£ " + (i).ToString("N");
            TLLBL.Text = "₺ " + ((i * n) / j).ToString("N");
            DolarLBL.Text = "$ " + ((i * n) / k).ToString("N");
            AltinLBL.Text = "gr " + ((i * n) / m).ToString("N");
        }
        // Altın için çevir.
        private void AltinRBTN_CheckedChanged(object sender, EventArgs e)
        {
            RefreshRate();
            AltinLBL.Text = "gr " + (i).ToString("N");
            TLLBL.Text = "₺ " + ((i * m) / j).ToString("N");
            DolarLBL.Text = "$ " + ((i * m) / k).ToString("N");
            EuroLBL.Text = "£ " + ((i * m) / n).ToString("N");
        }
        // _-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
        // /////// Coded by eodev/#RealBeGulum \\\\\\\\\
        // _-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-_
    }
}

