﻿namespace CSharpKurDegeriHesapla
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Panel2 = new System.Windows.Forms.Panel();
            this.MiktarLBL = new System.Windows.Forms.Label();
            this.MiktarTXT = new System.Windows.Forms.TextBox();
            this.AltinRBTN = new System.Windows.Forms.RadioButton();
            this.EuroRBTN = new System.Windows.Forms.RadioButton();
            this.DolarRBTN = new System.Windows.Forms.RadioButton();
            this.TLRBTN = new System.Windows.Forms.RadioButton();
            this.AltinLBL = new System.Windows.Forms.Label();
            this.AltinTXT = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.TLTxt = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.EuroLBL = new System.Windows.Forms.Label();
            this.TLLBL = new System.Windows.Forms.Label();
            this.DolarTXT = new System.Windows.Forms.TextBox();
            this.EuroTXT = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.DolarLBL = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Panel2.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel2
            // 
            this.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel2.Controls.Add(this.MiktarLBL);
            this.Panel2.Controls.Add(this.MiktarTXT);
            this.Panel2.Location = new System.Drawing.Point(19, 18);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(249, 59);
            this.Panel2.TabIndex = 15;
            // 
            // MiktarLBL
            // 
            this.MiktarLBL.AutoSize = true;
            this.MiktarLBL.Location = new System.Drawing.Point(78, 10);
            this.MiktarLBL.Name = "MiktarLBL";
            this.MiktarLBL.Size = new System.Drawing.Size(92, 13);
            this.MiktarLBL.TabIndex = 1;
            this.MiktarLBL.Text = "Çevrilecek Miktar:";
            // 
            // MiktarTXT
            // 
            this.MiktarTXT.Location = new System.Drawing.Point(28, 29);
            this.MiktarTXT.MaxLength = 8;
            this.MiktarTXT.Name = "MiktarTXT";
            this.MiktarTXT.Size = new System.Drawing.Size(190, 20);
            this.MiktarTXT.TabIndex = 0;
            this.MiktarTXT.Text = "1";
            this.MiktarTXT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AltinRBTN
            // 
            this.AltinRBTN.AutoSize = true;
            this.AltinRBTN.Location = new System.Drawing.Point(8, 171);
            this.AltinRBTN.Name = "AltinRBTN";
            this.AltinRBTN.Size = new System.Drawing.Size(14, 13);
            this.AltinRBTN.TabIndex = 16;
            this.AltinRBTN.TabStop = true;
            this.AltinRBTN.UseVisualStyleBackColor = true;
            this.AltinRBTN.CheckedChanged += new System.EventHandler(this.AltinRBTN_CheckedChanged);
            // 
            // EuroRBTN
            // 
            this.EuroRBTN.AutoSize = true;
            this.EuroRBTN.Location = new System.Drawing.Point(8, 121);
            this.EuroRBTN.Name = "EuroRBTN";
            this.EuroRBTN.Size = new System.Drawing.Size(14, 13);
            this.EuroRBTN.TabIndex = 15;
            this.EuroRBTN.TabStop = true;
            this.EuroRBTN.UseVisualStyleBackColor = true;
            this.EuroRBTN.CheckedChanged += new System.EventHandler(this.EuroRBTN_CheckedChanged);
            // 
            // DolarRBTN
            // 
            this.DolarRBTN.AutoSize = true;
            this.DolarRBTN.Location = new System.Drawing.Point(8, 75);
            this.DolarRBTN.Name = "DolarRBTN";
            this.DolarRBTN.Size = new System.Drawing.Size(14, 13);
            this.DolarRBTN.TabIndex = 14;
            this.DolarRBTN.TabStop = true;
            this.DolarRBTN.UseVisualStyleBackColor = true;
            this.DolarRBTN.CheckedChanged += new System.EventHandler(this.DolarRBTN_CheckedChanged);
            // 
            // TLRBTN
            // 
            this.TLRBTN.AutoSize = true;
            this.TLRBTN.Location = new System.Drawing.Point(8, 28);
            this.TLRBTN.Name = "TLRBTN";
            this.TLRBTN.Size = new System.Drawing.Size(14, 13);
            this.TLRBTN.TabIndex = 0;
            this.TLRBTN.UseVisualStyleBackColor = true;
            this.TLRBTN.CheckedChanged += new System.EventHandler(this.TLRBTN_CheckedChanged);
            // 
            // AltinLBL
            // 
            this.AltinLBL.AutoSize = true;
            this.AltinLBL.Location = new System.Drawing.Point(136, 170);
            this.AltinLBL.Name = "AltinLBL";
            this.AltinLBL.Size = new System.Drawing.Size(16, 13);
            this.AltinLBL.TabIndex = 13;
            this.AltinLBL.Text = "gr";
            // 
            // AltinTXT
            // 
            this.AltinTXT.Location = new System.Drawing.Point(28, 167);
            this.AltinTXT.MaxLength = 8;
            this.AltinTXT.Name = "AltinTXT";
            this.AltinTXT.Size = new System.Drawing.Size(100, 20);
            this.AltinTXT.TabIndex = 11;
            this.AltinTXT.Text = "248.54";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(45, 151);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(55, 13);
            this.Label9.TabIndex = 12;
            this.Label9.Text = "Altın Kuru:";
            // 
            // TLTxt
            // 
            this.TLTxt.Location = new System.Drawing.Point(28, 25);
            this.TLTxt.MaxLength = 8;
            this.TLTxt.Name = "TLTxt";
            this.TLTxt.Size = new System.Drawing.Size(100, 20);
            this.TLTxt.TabIndex = 2;
            this.TLTxt.Text = "1";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(45, 9);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(59, 13);
            this.Label2.TabIndex = 3;
            this.Label2.Text = "Türk Lirası:";
            // 
            // EuroLBL
            // 
            this.EuroLBL.AutoSize = true;
            this.EuroLBL.Location = new System.Drawing.Point(136, 120);
            this.EuroLBL.Name = "EuroLBL";
            this.EuroLBL.Size = new System.Drawing.Size(13, 13);
            this.EuroLBL.TabIndex = 10;
            this.EuroLBL.Text = "£";
            // 
            // TLLBL
            // 
            this.TLLBL.AutoSize = true;
            this.TLLBL.Location = new System.Drawing.Point(136, 28);
            this.TLLBL.Name = "TLLBL";
            this.TLLBL.Size = new System.Drawing.Size(13, 13);
            this.TLLBL.TabIndex = 4;
            this.TLLBL.Text = "₺";
            // 
            // DolarTXT
            // 
            this.DolarTXT.Location = new System.Drawing.Point(28, 71);
            this.DolarTXT.MaxLength = 8;
            this.DolarTXT.Name = "DolarTXT";
            this.DolarTXT.Size = new System.Drawing.Size(100, 20);
            this.DolarTXT.TabIndex = 5;
            this.DolarTXT.Text = "6.0572";
            // 
            // EuroTXT
            // 
            this.EuroTXT.Location = new System.Drawing.Point(28, 117);
            this.EuroTXT.MaxLength = 8;
            this.EuroTXT.Name = "EuroTXT";
            this.EuroTXT.Size = new System.Drawing.Size(100, 20);
            this.EuroTXT.TabIndex = 8;
            this.EuroTXT.Text = "6.7670";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(45, 55);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(60, 13);
            this.Label5.TabIndex = 6;
            this.Label5.Text = "Dolar Kuru:";
            // 
            // DolarLBL
            // 
            this.DolarLBL.AutoSize = true;
            this.DolarLBL.Location = new System.Drawing.Point(136, 74);
            this.DolarLBL.Name = "DolarLBL";
            this.DolarLBL.Size = new System.Drawing.Size(13, 13);
            this.DolarLBL.TabIndex = 7;
            this.DolarLBL.Text = "$";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(45, 101);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(57, 13);
            this.Label7.TabIndex = 9;
            this.Label7.Text = "Euro Kuru:";
            // 
            // Panel1
            // 
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel1.Controls.Add(this.AltinRBTN);
            this.Panel1.Controls.Add(this.EuroRBTN);
            this.Panel1.Controls.Add(this.DolarRBTN);
            this.Panel1.Controls.Add(this.TLRBTN);
            this.Panel1.Controls.Add(this.AltinLBL);
            this.Panel1.Controls.Add(this.AltinTXT);
            this.Panel1.Controls.Add(this.Label9);
            this.Panel1.Controls.Add(this.TLTxt);
            this.Panel1.Controls.Add(this.Label2);
            this.Panel1.Controls.Add(this.EuroLBL);
            this.Panel1.Controls.Add(this.TLLBL);
            this.Panel1.Controls.Add(this.Label7);
            this.Panel1.Controls.Add(this.DolarTXT);
            this.Panel1.Controls.Add(this.EuroTXT);
            this.Panel1.Controls.Add(this.Label5);
            this.Panel1.Controls.Add(this.DolarLBL);
            this.Panel1.Location = new System.Drawing.Point(19, 83);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(249, 210);
            this.Panel1.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 310);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(303, 349);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kur Hesaplama";
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Label MiktarLBL;
        internal System.Windows.Forms.TextBox MiktarTXT;
        internal System.Windows.Forms.RadioButton AltinRBTN;
        internal System.Windows.Forms.RadioButton EuroRBTN;
        internal System.Windows.Forms.RadioButton DolarRBTN;
        internal System.Windows.Forms.RadioButton TLRBTN;
        internal System.Windows.Forms.Label AltinLBL;
        internal System.Windows.Forms.TextBox AltinTXT;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox TLTxt;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label EuroLBL;
        internal System.Windows.Forms.Label TLLBL;
        internal System.Windows.Forms.TextBox DolarTXT;
        internal System.Windows.Forms.TextBox EuroTXT;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label DolarLBL;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Panel Panel1;
    }
}

